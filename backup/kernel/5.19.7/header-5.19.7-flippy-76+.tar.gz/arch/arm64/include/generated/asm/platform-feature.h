#include <asm-generic/platform-feature.h>
