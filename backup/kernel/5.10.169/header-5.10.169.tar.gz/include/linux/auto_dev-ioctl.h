/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 * Copyright 2008 Red Hat, Inc. All rights reserved.
 * Copyright 2008 Ian Kent <raven@themaw.net>
 */

#ifndef _LINUX_AUTO_DEV_IOCTL_H
#define _LINUX_AUTO_DEV_IOCTL_H

#include <uapi/linux/auto_dev-ioctl.h>
#endif	/* _LINUX_AUTO_DEV_IOCTL_H */
